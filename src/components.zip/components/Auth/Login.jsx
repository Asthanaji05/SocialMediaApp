import React, { useState } from 'react';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleGoogleLogin = () => {
        window.location.href = "http://localhost:3000/auth/google";
    };

    const handleEmailLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:3000/auth", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
            });
            if (response.ok) {
                const data = await response.json();
                console.log("Login successful:", data);
            } else {
                console.error("Login failed");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center h-screen space-y-4">
            <button 
                onClick={handleGoogleLogin} 
                className="px-4 py-2 bg-blue-500 text-white rounded-md">
                Login with Google
            </button>
            <form onSubmit={handleEmailLogin} className="flex flex-col space-y-2">
                <input 
                    type="email" 
                    placeholder="Email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                    className="px-4 py-2 border rounded-md"
                />
                <input 
                    type="password" 
                    placeholder="Password" 
                    value={password} 
                    onChange={(e) => setPassword(e.target.value)} 
                    className="px-4 py-2 border rounded-md"
                />
                <button 
                    type="submit" 
                    className="px-4 py-2 bg-green-500 text-white rounded-md">
                    Login with Email
                </button>
            </form>
        </div>
    );
};

export default Login;
