import React from 'react';
import { Settings, MapPin, Link as LinkIcon } from 'lucide-react';
import Post from '../Feed/Post';

const UserProfile = () => {
  const posts = [
    {
      username: "johndoe",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      content: "Just another day at the office! 💼",
      image: "https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80",
      likes: 124,
      comments: 8
    }
  ];

  return (
    <div className="max-w-4xl mx-auto pt-20 px-4">
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-5">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
              alt="Profile"
              className="w-24 h-24 rounded-full object-cover"
            />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">John Doe</h1>
              <p className="text-gray-500">@johndoe</p>
              <div className="flex items-center mt-2 text-sm text-gray-500">
                <MapPin className="h-4 w-4 mr-1" />
                <span>San Francisco, CA</span>
                <LinkIcon className="h-4 w-4 ml-4 mr-1" />
                <a href="#" className="text-indigo-600">website.com</a>
              </div>
            </div>
          </div>
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
            <Settings className="h-4 w-4 mr-2" />
            Edit Profile
          </button>
        </div>
        
        <div className="mt-6">
          <p className="text-gray-700">
            Full-stack developer passionate about creating beautiful and functional web applications.
          </p>
        </div>

        <div className="mt-6 flex space-x-6">
          <div>
            <span className="font-bold text-gray-900">1,234</span>
            <span className="ml-1 text-gray-500">Posts</span>
          </div>
          <div>
            <span className="font-bold text-gray-900">5.6K</span>
            <span className="ml-1 text-gray-500">Followers</span>
          </div>
          <div>
            <span className="font-bold text-gray-900">456</span>
            <span className="ml-1 text-gray-500">Following</span>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {posts.map((post, index) => (
          <Post key={index} {...post} />
        ))}
      </div>
    </div>
  );
};

export default UserProfile;