import React from "react";

const Post = ({ username, avatar, content, image, likes, comments }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center space-x-4">
        <img src={avatar} alt={username} className="w-10 h-10 rounded-full" />
        <h2 className="font-semibold">{username}</h2>
      </div>
      <p className="mt-2">{content}</p>
      {image && <img src={image} alt="Post" className="w-full mt-2 rounded-lg" />}
      <div className="mt-2 flex justify-between text-gray-500 text-sm">
        <span>👍 {likes}</span>
        <span>💬 {comments}</span>
      </div>
    </div>
  );
};

export default Post;  // ✅ Yeh line zaroori hai
