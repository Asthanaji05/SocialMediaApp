import React from "react";

const Logout = () => {
  const handleLogout = async () => {
    try {
      await fetch("http://localhost:3000/auth/logout", {
        method: "GET",
        credentials: "include", // Session maintain karne ke liye
      });
      window.location.href = "/"; // Logout hone ke baad redirect
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen">
      <button 
        onClick={handleLogout} 
        className="px-4 py-2 bg-red-500 text-white rounded-md">
        Logout
      </button>
    </div>
  );
};

export default Logout;
